/*
 * Copyright (c) 2017
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package ui.controller;

import event.EventBus;
import event.GameEvent;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.canvas.Canvas;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import logic.gamehandler.GameHandler;
import ui.drawer.*;

import java.io.File;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.ResourceBundle;

public class BoardController extends DockNodeController implements Initializable {

	@FXML
	Pane boardPane;
	@FXML
	VBox sideBar;
	Canvas boardCanvas;
	GameDrawer gameDrawer;

	@FXML
	ImageView imageView;
	@FXML
	MediaView mediaView;

	private GameHandler game;
	private String fxmlLocation;

	private Queue<Node> sideBarItems;
	private MediaPlayer player;


	BoardController(GameHandler gameHandler, String resourcePath) {
		game = gameHandler;
		fxmlLocation = resourcePath;
		sideBarItems = new ArrayDeque<>();
	}

	public final void addToSideBar(Node node) {
		sideBarItems.add(node);
	}

	@Override
	public void initialize(URL url, ResourceBundle resourceBundle) {
		EventBus.addEventHandler(GameEvent.GAMEOVER, this::enterScoring);
		EventBus.addEventHandler(GameEvent.REVIEWSTART, this::reviewStart);
		//File file = new File("src/kaya.jpg");
		//Image image =new Image(file.toURI().toString());
		//imageView.setImage(image);

		setupPanes();
		constructCanvas();
		setupSideBar();

		GameEvent.fireGameEvent(game, GameEvent.START);
		Media m = null;
		try {
			m = new Media( getClass().getResource("/sound/sound6.mp3").toURI().toString());
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}


		player = new MediaPlayer(m);
		player.setVolume(1);
		EventBus.addEventHandler(GameEvent.ANY, event -> player.play());
		mediaView.setMediaPlayer(player);
	}

	void setupPanes() {
		boardPane.widthProperty().addListener(this::resizeCanvas);
		boardPane.heightProperty().addListener(this::resizeCanvas);
	}

	private void constructCanvas() {
		boardCanvas = new Canvas();
		boardCanvas.setOnMouseMoved(this::canvasHover);
		boardCanvas.setOnMouseClicked(this::canvasClicked);
		boardCanvas.setOnMouseExited(this::canvasExit);

		boardPane.getChildren().add(boardCanvas);

		gameDrawer = buildGameDrawer();
	}

	GameDrawer buildGameDrawer() {
		GameDrawer drawer = new GameDrawer(boardCanvas, getGameHandler());

		Image  kaya = new Image("/images/kaya.jpg", false);
		Image Kayabackground = new Image("/images/kaya_background.jpg", false);
		Image whiteStone1 = new Image("/images/img_hanajirushi.png", false);
		Image whiteStone2 = new Image("/images/img_yukijirushi.png", false);



		Image blackStone = new Image("/images/black.png", false);
		Image whiteStone = new Image("/images/white.png", false);

		//Image whiteStone1 = new Image("/images/white.png", false);
		StoneDrawer stoneDrawer = new TexturedStoneDrawer(boardCanvas, blackStone, whiteStone);

		/// if you click on the whitestone1 the the TexturedStoneDrawer changes to new TexturedStoneDrawer(boardCanvas, blackStone, whiteStone1);
		drawer.setStoneDrawer(stoneDrawer);

		Image wood = new Image("/images/wood.jpg", false);
		Image lines = new Image("/images/grid.png", false);

		Image wood1 = new Image("/images/wood.jpg", false);
		BoardDrawer boardDrawer = new TexturedBoardDrawer(boardCanvas, kaya, lines);
		/// if you click on the wood1 the the TexturedBoardDrawer chancges to new TexturedBoardDrawer(boardCanvas, wood1, lines);
		drawer.setBoardDrawer(boardDrawer);

		return drawer;
	}

	GameHandler getGameHandler() {
		return game;
	}

	private void setupSideBar() {
		while (!sideBarItems.isEmpty()) {
			sideBar.getChildren().add(sideBarItems.remove());
		}
	}

	private void resizeCanvas(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
		boardCanvas.setHeight(boardPane.getHeight());
		boardCanvas.setWidth(boardPane.getWidth());
	}

	void canvasClicked(MouseEvent mouseEvent) {
	}

	void canvasHover(MouseEvent mouseEvent) {
	}

	void canvasExit(MouseEvent mouseEvent) {
	}

	void enterScoring(GameEvent event) {
	}

	void reviewStart(GameEvent event) {
	}

	@Override
	protected String getResourcePath() {
		return fxmlLocation;
	}
}

package ui.controller;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.SpinnerValueFactory.ListSpinnerValueFactory;
import javafx.util.StringConverter;
import logic.gamehandler.GameHandler;
import logic.gamehandler.LocalGameHandler;
import org.dockfx.DockNode;
import org.dockfx.DockPos;
import ui.Main;
import util.KomiSpinnerFactory;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;





public class NewBoardGameMenu extends DockNodeController implements Initializable{

    public Spinner<Integer> handicapSpinner;
    public Button startButton;
    public Spinner<Double> komiSpinner;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
      //  setupHandicapSpinner();
        setupKomiSpinner();

        startButton.setOnAction(this::start);
    }

  /*  private void setupHandicapSpinner() {
        ObservableList<Integer> handicaps = FXCollections.observableArrayList(new ArrayList<>());
        handicaps.add(0);
        for (int i = 2; i < 10; i++)
            handicaps.add(i);

        SpinnerValueFactory<Integer> handicapFactory = new ListSpinnerValueFactory<>(handicaps);
        handicapFactory.setWrapAround(true);
        handicapFactory.setConverter(new NewLocalGameController.HandicapConverter());

        handicapSpinner.setValueFactory(handicapFactory);
        handicapSpinner.setEditable(true);
    }*/


    private void setupKomiSpinner() {
        komiSpinner.setValueFactory(new KomiSpinnerFactory());
        komiSpinner.setEditable(true);
    }

    private void start(ActionEvent event) {
        DockNode node = buildLocalGame();
        node.setTitle("Local Game");
        node.dock(Main.instance.dockPane, DockPos.CENTER);

        getDockNode().close();
    }

    private DockNode buildLocalGame() {
        GameHandler handler = new LocalGameHandler(handicapSpinner.getValue());
        handler.setKomi(komiSpinner.getValue());

        LocalGameController controller = new LocalGameController(handler);

        return controller.getDockNode();
    }


    @Override
    protected String getResourcePath() {
        return "/fxml/NewBoardGameMenu.fxml";
    }

  /*  private class HandicapConverter extends StringConverter<Integer> {

        @Override
        public String toString(Integer object) {
            return object.toString();
        }

        @Override
        public Integer fromString(String string) {
            Integer result = Integer.parseInt(string);
            if ( result == 0 || (result > 1 && result < 10) )
                return result;
            else
                return 0;
        }
    }*/
}

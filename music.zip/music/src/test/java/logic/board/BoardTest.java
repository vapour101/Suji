/*
 * Copyright (c) 2017
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package logic.board;

import org.junit.Test;
import util.Coords;
import util.StoneColour;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static util.Coords.getCoords;
import static util.Move.play;

public class BoardTest {

	@Test
	public void equals() {
		Board board1 = new Board();
		Board board2 = new Board();

		board1.playStone(play(getCoords("D4"), StoneColour.BLACK));
		board1.playStone(play(getCoords("C4"), StoneColour.BLACK));
		board1.playStone(play(getCoords("M17"), StoneColour.WHITE));
		board1.playStone(play(getCoords("R4"), StoneColour.WHITE));
		board1.playStone(play(getCoords("B14"), StoneColour.BLACK));

		board2.playStone(play(getCoords("R4"), StoneColour.WHITE));
		board2.playStone(play(getCoords("B14"), StoneColour.BLACK));
		board2.playStone(play(getCoords("C4"), StoneColour.BLACK));
		board2.playStone(play(getCoords("D4"), StoneColour.BLACK));
		board2.playStone(play(getCoords("M17"), StoneColour.WHITE));

		assertThat(board1, is(board2));

		assertThat(board1, is(board1));
		assertThat(board1, is(not(getCoords("D4"))));
	}

	@Test
	public void playMoves() {
		Board board = new Board();

		Coords coords = getCoords("D4");
		board.playStone(play(coords, StoneColour.BLACK));
		assertThat(board.getStones(StoneColour.BLACK), hasItems(coords));

		coords = getCoords("E5");
		board.playStone(play(coords, StoneColour.WHITE));
		assertThat(board.getStones(StoneColour.WHITE), hasItems(coords));
	}

	@Test
	public void findingChains() {
		Board board = new Board();

		String[] stones = {"D3", "D4", "D5", "E6"};

		for (String stone : stones)
			board.playStone(play(getCoords(stone), StoneColour.BLACK));

		stones = new String[]{"F5", "F6"};
		for (String stone : stones)
			board.playStone(play(getCoords(stone), StoneColour.WHITE));

		assertThat(board.getChainAtCoords(getCoords("D4")).getStones(),
				   hasItems(getCoords("D3"), getCoords("D4"), getCoords("D5")));

		assertThat(board.getChainAtCoords(getCoords("D3")).getStones(),
				   hasItems(getCoords("D3"), getCoords("D4"), getCoords("D5")));

		assertThat(board.getChainAtCoords(getCoords("E6")).getStones(), hasItem(getCoords("E6")));

		assertThat(board.getChainAtCoords(getCoords("D4")).size(), is(3));
		assertThat(board.getChainAtCoords(getCoords("D5")).size(), is(3));
		assertThat(board.getChainAtCoords(getCoords("E6")).size(), is(1));
		assertThat(board.getChainAtCoords(getCoords("F5")).size(), is(2));

		assertThat(board.getChainAtCoords(getCoords("F5")).getStones(), hasItems(getCoords("F5"), getCoords("F6")));

		assertThat(board.getChainAtCoords(getCoords("A1")), nullValue());
	}

	@Test
	public void blockOccupiedSameColourBlack() {
		Board board = new Board();

		board.playStone(play(getCoords("C4"), StoneColour.BLACK));

		try {
			board.playStone(play(getCoords("C4"), StoneColour.BLACK));
			fail("Board did not throw exception when playing on top of an existing stone with a stone of the same colour.");
		}
		catch (Exception e) {
			assertThat(e, instanceOf(IllegalArgumentException.class));
		}
	}

	@Test
	public void blockOccupiedDifferentColourBlack() {
		Board board = new Board();

		board.playStone(play(getCoords("C4"), StoneColour.BLACK));

		try {
			board.playStone(play(getCoords("C4"), StoneColour.WHITE));
			fail("Board did not throw exception when playing on top of an existing stone with a stone of a different colour.");
		}
		catch (Exception e) {
			assertThat(e, instanceOf(IllegalArgumentException.class));
		}
	}

	@Test
	public void blockOccupiedSameColourWhite() {
		Board board = new Board();

		board.playStone(play(getCoords("C4"), StoneColour.WHITE));

		try {
			board.playStone(play(getCoords("C4"), StoneColour.WHITE));
			fail("Board did not throw exception when playing on top of an existing stone with a stone of the same colour.");
		}
		catch (Exception e) {
			assertThat(e, instanceOf(IllegalArgumentException.class));
		}
	}

	@Test
	public void blockOccupiedDifferentColourWhite() {
		Board board = new Board();

		board.playStone(play(getCoords("C4"), StoneColour.WHITE));

		try {
			board.playStone(play(getCoords("C4"), StoneColour.BLACK));
			fail("Board did not throw exception when playing on top of an existing stone with a stone of a different colour.");
		}
		catch (Exception e) {
			assertThat(e, instanceOf(IllegalArgumentException.class));
		}
	}

	@Test
	public void simpleCapturing() {
		Board board = new Board();

		assertThat(board.getCaptures(StoneColour.BLACK), is(0));
		assertThat(board.getCaptures(StoneColour.WHITE), is(0));

		board.playStone(play(getCoords("D4"), StoneColour.BLACK));
		board.playStone(play(getCoords("D3"), StoneColour.WHITE));
		board.playStone(play(getCoords("D5"), StoneColour.WHITE));
		board.playStone(play(getCoords("C4"), StoneColour.WHITE));

		assertThat(board.getStones(StoneColour.BLACK).size(), is(1));
		assertThat(board.getStones(StoneColour.WHITE).size(), is(3));
		assertThat(board.getCaptures(StoneColour.BLACK), is(0));
		assertThat(board.getCaptures(StoneColour.WHITE), is(0));

		board.playStone(play(getCoords("E4"), StoneColour.WHITE));

		assertThat(board.getCaptures(StoneColour.WHITE), is(1));
		assertThat(board.getStones(StoneColour.BLACK).size(), is(0));


		board = new Board();

		assertThat(board.getCaptures(StoneColour.BLACK), is(0));
		assertThat(board.getCaptures(StoneColour.WHITE), is(0));

		board.playStone(play(getCoords("D4"), StoneColour.WHITE));
		board.playStone(play(getCoords("D3"), StoneColour.BLACK));
		board.playStone(play(getCoords("D5"), StoneColour.BLACK));
		board.playStone(play(getCoords("C4"), StoneColour.BLACK));

		assertThat(board.getStones(StoneColour.BLACK).size(), is(3));
		assertThat(board.getStones(StoneColour.WHITE).size(), is(1));
		assertThat(board.getCaptures(StoneColour.BLACK), is(0));
		assertThat(board.getCaptures(StoneColour.WHITE), is(0));

		board.playStone(play(getCoords("E4"), StoneColour.BLACK));

		assertThat(board.getCaptures(StoneColour.BLACK), is(1));
		assertThat(board.getStones(StoneColour.WHITE).size(), is(0));
	}
}
